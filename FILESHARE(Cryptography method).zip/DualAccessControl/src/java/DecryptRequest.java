   import java.io.*;
   import java.sql.*;
   import javax.servlet.*;
   import javax.servlet.http.*;
   public class DecryptRequest extends HttpServlet {
    String username="";
    String password="";
    String type1="",key2="";
    Connection con=null;
    Statement st=null,st1=null,st2=null;
    ResultSet rs=null,rs1=null,rs2=null;
    
    public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException,ServletException {
        String fileid = req.getParameter("filSelect");
       
	HttpSession sn = req.getSession(true);
    // sn.setAttribute("username",username);
    	RequestDispatcher rd = null;
                
        try {
           
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sedasc","root","password");
            st = con.createStatement();
            rs = st.executeQuery("select * from uploadlist where fileid='"+fileid+"'");
            
            
            if(rs.next()) {
                
               String query = "update uploadlist set status1 = ? where fileid = ?";
      PreparedStatement preparedStmt = con.prepareStatement(query);
      preparedStmt.setString   (1, "requested");
      preparedStmt.setString(2, fileid);

      // execute the java preparedstatement
      preparedStmt.executeUpdate();
                rd=req.getRequestDispatcher("receiveddata1.jsp");
                		
            } 
            
            else {

               rd=req.getRequestDispatcher("changepassfailure.jsp");
	        }
	     rd.forward(req,res);
        }
        catch(Exception e2)
         {
            System.out.println("Exception : "+e2.toString());
        }
    }
}