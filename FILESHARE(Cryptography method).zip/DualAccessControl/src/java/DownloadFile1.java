/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.sql.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.Security;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import de.flexiprovider.core.FlexiCoreProvider;
import java.util.Random;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpSession;

/**
 *
 * @author GOWTHAM
 */
public class DownloadFile1 extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
     private String algo="AES/ECB/PKCS5Padding";
     
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       // PrintWriter out = response.getWriter();
        try {
            String filSelect = request.getParameter("filSelect");
            
             String key1 = request.getParameter("key1");
            String originalName = filSelect;
            String primary = null;
            //String seckey="";
            RequestDispatcher rd;
            //int count = 0;
            Object obj;
            int i=0;
            byte[] block = new byte[8];
            String email2="";
            
            HttpSession sn = request.getSession(true);
   //  sn.setAttribute("username",username);
     // System.out.println(""+username2+","+filSelect);
            Class.forName("com.mysql.jdbc.Driver").newInstance();
           Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sedasc","root","password");
           
          
                String query = "select * from uploadlist where fileid='" + filSelect +"' && key1='" + key1 +"'"; 
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);
            if (rs.next()) {
                String key2 = key1+rs.getString(6);
                originalName = rs.getString(3);
                 System.out.println(originalName);
                File f = new File ("E:\\UploadedFiles\\"+originalName+"");
                String my=f.getPath();
                System.out.println(my);
                String filename=f.getName();
                System.out.println(filename);
                String type=getMimeType("file:"+my);
                System.out.println("pass 1");

    response.setContentType (type);
    System.out.println("pass 2");
    response.setHeader ("Content-Disposition", "attachment;     filename=\""+filename+"\"");
    System.out.println("pass 3");
    String name = f.getName().substring(f.getName().lastIndexOf("/") + 1,f.getName().length());
    System.out.println("pass 4");
    InputStream in = new FileInputStream(f);
    System.out.println("pass 5");
    ServletOutputStream outs = response.getOutputStream();
    System.out.println("pass 6");
    
  
//SecretKey secKey = (SecretKey) obj;
 //cipher.init(Cipher.DECRYPT_MODE, secKey);

 FileInputStream fis = new FileInputStream(f);
 
 File file=new File("E:\\Downloads\\"+originalName+"");
 
   
         FileOutputStream fos =new FileOutputStream(file);               
         //generating same key
         byte k[] = key2.getBytes();   
         SecretKeySpec key = new SecretKeySpec(k,algo.split("/")[0]);  
         //creating and initialising cipher and cipher streams
         Cipher decrypt =  Cipher.getInstance(algo);  
         decrypt.init(Cipher.DECRYPT_MODE, key);  
         CipherInputStream cin=new CipherInputStream(fis, decrypt);
         

 
   byte[] buf = new byte[1024];
         int read=0;
         while((read=cin.read(buf))!=-1)  //reading encrypted data
              fos.write(buf,0,read);  //writing decrypted data
         //closing streams
         cin.close();
         fos.flush();
         fos.close();
 

            }
            else
            {
                
             
                 rd = request.getRequestDispatcher("downloadfailure.jsp");
                rd.forward(request, response);
               
              
            }
           

        }  
        catch (Exception ex) {
            System.out.print(ex);
        }
        finally {
           // out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    public static String getMimeType(String fileUrl)throws java.io.IOException, MalformedURLException 
  {
    String type = null;
    URL u = new URL(fileUrl);
    URLConnection uc = null;
    uc = u.openConnection();
    type = uc.getContentType();
    return type;
  }
}
